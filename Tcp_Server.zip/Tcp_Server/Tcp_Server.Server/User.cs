﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tcp_Server.Server {
    internal class User {
        public User(String userid, string password) {}
    }
}
